#include "stdafx.h"
#include "StartScene.h"

StartScene::StartScene()
{
}

StartScene::~StartScene()
{
	if (m_UiShader) m_UiShader->ReleaseObjects();
	SAFE_DELETE(m_UiShader);
}

bool StartScene::Initialize(ID3D12Device * pd3dDevice, ID3D12GraphicsCommandList * pd3dCommandList)
{
	CScene::Initialize(pd3dDevice, pd3dCommandList);
	
	m_pCamera = GenerateCamera(THIRD_PERSON_CAMERA, m_pPlayer);
	m_pCamera->SetTimeLag(0.f);
	m_pCamera->SetOffset(XMFLOAT3(0.0f, 50.0f, -40.0f));
	m_pCamera->GenerateProjectionMatrix(1.0f, 5000.0f, ASPECT_RATIO, 60.0f);
	m_pCamera->SetViewport(0, 0, FRAME_BUFFER_WIDTH, FRAME_BUFFER_HEIGHT);
	m_pCamera->CreateShaderVariables(pd3dDevice, pd3dCommandList);

	m_UiShader = new UIShader();
	m_UiShader->CreateGraphicsRootSignature(pd3dDevice);
	m_UiShader->CreateStartShader(pd3dDevice, 1);
	m_UiShader->StartScene(pd3dDevice, pd3dCommandList);

	CreateShaderVariables(pd3dDevice, pd3dCommandList);

	return true;
}

void StartScene::Render(ID3D12GraphicsCommandList * pd3dCommandList, CCamera * pCamera)
{
	pd3dCommandList->SetGraphicsRootSignature(m_pd3dGraphicsRootSignature);

	m_pCamera->SetViewportsAndScissorRects(pd3dCommandList);
	m_pCamera->UpdateShaderVariables(pd3dCommandList);

	
	m_UiShader->RenderStartScene(pd3dCommandList, m_pCamera);
}

